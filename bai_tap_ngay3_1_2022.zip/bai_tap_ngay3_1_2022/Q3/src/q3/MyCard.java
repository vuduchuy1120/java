/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package q3;

/**
 *
 * @author Kudo
 */
public class MyCard {

    String cardNumber;
    String cardType;

    public MyCard(String ctype, String cnumber) {
        this.cardNumber = cnumber;
        this.cardType = ctype;
    }

    public int check(String a) {
        for (int i = 0; i < cardNumber.length(); i++) {
            if (!Character.isLetter(cardNumber.charAt(i))) {
                return 0;
            }
        }
        return 1;
    }

    public String getCardCode() {
        
        if (cardNumber.length() > 4 && check(cardNumber) == 1) {
            if (cardType.equalsIgnoreCase("credit")) {
                return String.format("%c%c%c%c", cardNumber.charAt(cardNumber.length() - 4), cardNumber.charAt(cardNumber.length() - 3), cardNumber.charAt(cardNumber.length() - 2), cardNumber.charAt(cardNumber.length() - 1));
            } else {
                return String.format("%c%c%c%c", cardNumber.charAt(0), cardNumber.charAt(1), cardNumber.charAt(2), cardNumber.charAt(3));
            }
        }
        else if(check(cardNumber) == 0){
            return cardNumber="0000";
        }
        else 
            return cardNumber;
        
        
    }

    @Override
    public String toString() {
        return cardType + " " + getCardCode();
    }

}
