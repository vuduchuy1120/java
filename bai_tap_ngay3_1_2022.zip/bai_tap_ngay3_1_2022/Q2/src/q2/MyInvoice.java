/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package q2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;


public class MyInvoice implements IInvoice{

@Override   
    public String f1(ArrayList<Invoice> a, int st) 
    {   
        
    
        if(st==1)
        {
            for (int i = 0; i < a.size() - 1; i++) {
                for (int j = i+1; j < a.size(); j++) {
                    if(a.get(i).name.compareToIgnoreCase(a.get(j).name) > 0){
                        Invoice tmp = a.get(i);
                        a.set(i, a.get(j));
                        a.set(j, tmp);
                    }
                }
            }
            for (int i = 0; i < a.size(); i++) {
                System.out.println(a.get(i).name);
            }
            return a.get(1).name;
        }
        else if(st==2)
        { 
            for (int i = 0; i < a.size() - 1; i++) {
                for (int j = i+1; j < a.size(); j++) {
                    if(a.get(i).total > a.get(j).total){
                        Invoice tmp = a.get(i);
                        a.set(i, a.get(j));
                        a.set(j, tmp);
                    }
                }
            }
            return a.get(1).name;
        }
        return "No";
    }           
            
       
  
    @Override
    public int f2(ArrayList<Invoice> a) {
        int max1 = -1000000;
        int max2 = -1000000;
        for (int i = 0; i < a.size(); i++) {
            if(a.get(i).total > max1){
                max2 = max1;
                max1 = a.get(i).total;
            }
            else if(a.get(i).total > max2){
                max2 = a.get(i).total;
            }
        }
        for (int i = 0; i < a.size(); i++) {
            if(a.get(i).total == max1 || a.get(i).total == max2){
                a.remove(i);
                i--;
            }
        }
        int sum = 0;
        for (int i = 0; i < a.size(); i++) {
            sum += a.get(i).total;
        }
        return sum;
    }
    
}
