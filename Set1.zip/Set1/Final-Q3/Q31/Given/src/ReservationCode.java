public class ReservationCode {
    String name;
    String code;
    
    public ReservationCode(String code, String customerName) {
        this.code = code;
        this.name = customerName;
    }
    
     
    String getCode() {
        String codeAfter = "";
        for (int i = 0; i < code.length(); i++) {
            codeAfter += code.charAt(i);
            if(i % 2 != 0 && i != code.length()-1)
                codeAfter += "-";
        }
        return String.format("%s", codeAfter);
    }
    
    
    
    /*add and complete your other methods here (if needed)*/

    @Override
    public String toString() {
        return  name + "\t" + code ;
    }
    
}
