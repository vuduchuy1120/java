
public class VNMotor extends Motor{  
    
    String series;
    
    public VNMotor() {
    }

    public VNMotor(String series) {
        this.series = series;
    }  
    
    public VNMotor(String brandName, String series, double price) {
        super(brandName, price);
        this.series = series;
    }


    /*Complete the below function for second test case*/
    public double getSalePrice() {
        if(price < 3000)
            return price - price*(double)5/100;
        else
            return price - price*(double)10/100;
    }
    //add and complete your other methods here (if needed)

    @Override
    public String toString() {
        return brand + "\t" + series +"\t"+ price ;
    }
    
}
